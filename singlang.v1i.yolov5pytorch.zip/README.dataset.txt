# singlang > 2024-10-02 11:07am
https://universe.roboflow.com/vamsi-dama007/singlang-ilijw

Provided by a Roboflow user
License: CC BY 4.0

